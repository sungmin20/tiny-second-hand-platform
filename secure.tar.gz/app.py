from flask import Flask, render_template, redirect, url_for, flash, request
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from flask_wtf.csrf import CSRFProtect
from flask_socketio import SocketIO, emit, join_room, leave_room
from flask_migrate import Migrate
from functools import wraps

from models import db, User, Product, ReportProduct, ReportUser, Transaction, GlobalMessage, Review, Message
from forms import RegisterForm, LoginForm, UpdateProfileForm, ProductForm, ReportForm, TransferForm, ReviewForm, BuyProductForm

# ✅ 1. 먼저 app 객체부터 생성
app = Flask(__name__)
app.config['SECRET_KEY'] = 'supersecretkey'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///market.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# ✅ 2. 그 다음에 extensions 초기화
db.init_app(app)
migrate = Migrate(app, db)
csrf = CSRFProtect(app)
socketio = SocketIO(app)

login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

# ✅ 3. 여기에 before_first_request 등록해야 함
#@app.before_first_request
#def create_tables():
#    db.create_all()

# ✅ 4. user_loader 등록
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


# 메인 페이지
@app.route('/')
def index():
    return render_template('index.html')

# 회원가입
@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        existing_user = User.query.filter_by(username=form.username.data).first()
        if existing_user:
            flash('이미 존재하는 사용자입니다.', 'danger')
            return redirect(url_for('register'))

        user = User(
            username=form.username.data,
            password=form.password.data  # ⚠ 추후 해시처리 필요
        )
        db.session.add(user)
        db.session.commit()
        flash('회원가입이 완료되었습니다.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', form=form)

# 로그인
@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.password == form.password.data:
            if not user.is_active_user:  # 휴면 상태 체크
                flash('휴면 상태인 사용자입니다. 관리자에게 문의해주세요.', 'danger')
                return redirect(url_for('login'))
            login_user(user)
            return redirect(url_for('index'))
        flash('로그인 실패. 아이디나 비밀번호를 확인해주세요.', 'danger')
    return render_template('login.html', form=form)


# 로그아웃
@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('로그아웃되었습니다.', 'info')
    return redirect(url_for('index'))

@app.route('/mypage', methods=['GET', 'POST'])
@login_required
def mypage():
    form = UpdateProfileForm()

    if form.validate_on_submit():
        if form.introduction.data is not None:
            current_user.introduction = form.introduction.data
        if form.new_password.data:
            current_user.password = form.new_password.data  # 추후 해시 필요
        db.session.commit()
        db.session.refresh(current_user)  # ✅ 꼭 있어야 최신값 반영됨
        flash('프로필이 업데이트되었습니다.', 'success')
        return redirect(url_for('mypage'))

    form.introduction.data = current_user.introduction
    return render_template('mypage.html', form=form)

@app.route('/new_product', methods=['GET', 'POST'])
@login_required
def new_product():
    # 휴면 상태인 유저는 상품을 등록할 수 없습니다.
    if not current_user.is_active_user:
        flash('휴면 상태로 상품을 등록할 수 없습니다.', 'danger')
        return redirect(url_for('index'))  # 홈으로 리디렉션

    form = ProductForm()
    if form.validate_on_submit():
        product = Product(
            title=form.title.data,
            description=form.description.data,
            price=form.price.data,
            owner=current_user
        )
        db.session.add(product)
        db.session.commit()
        flash('상품이 등록되었습니다.', 'success')
        return redirect(url_for('products'))  # 상품 목록 페이지로 리디렉션

    return render_template('new_product.html', form=form)


@app.route('/products')
def products():
    product_list = Product.query.order_by(Product.created_at.desc()).all()
    return render_template('products.html', products=product_list)

@app.route('/product/<int:product_id>', methods=['GET', 'POST'])
def product_detail(product_id):
    product = Product.query.get_or_404(product_id)
    form = BuyProductForm()  # 폼 객체 생성

    if form.validate_on_submit():  # 폼 제출 처리
        return redirect(url_for('buy_product', product_id=product.id))

    return render_template('product_detail.html', product=product, form=form)

@app.route('/chat')
@login_required
def chat():
    messages = GlobalMessage.query.order_by(GlobalMessage.timestamp.asc()).all()
    return render_template('chat.html', messages=messages)


@socketio.on('join')
def handle_join(username):
    print(f'{username} joined the chat')

@socketio.on('send_message')
def handle_send_message(data):
    emit('receive_message', data, broadcast=True)

@app.route('/chat/<int:user_id>')
@login_required
def chat_private(user_id):
    other_user = User.query.get_or_404(user_id)
    if other_user.id == current_user.id:
        flash('자기 자신과는 채팅할 수 없습니다.', 'warning')
        return redirect(url_for('index'))

    # 기존 메시지 불러오기
    messages = Message.query.filter(
        ((Message.sender_id == current_user.id) & (Message.receiver_id == user_id)) |
        ((Message.sender_id == user_id) & (Message.receiver_id == current_user.id))
    ).order_by(Message.timestamp.asc()).all()

    return render_template('chat_private.html', other_user=other_user, messages=messages)

@socketio.on('join_room')
def handle_join_room(data):
    room = data['room']
    join_room(room)
    print(f"Joined room: {room}")

@socketio.on('send_private')
def handle_send_private(data):
    room = data['room']
    sender_id = data['sender_id']
    receiver_id = data['receiver_id']
    message_text = data['message']

    # 메시지 저장
    msg = Message(
        sender_id=sender_id,
        receiver_id=receiver_id,
        content=message_text
    )
    db.session.add(msg)
    db.session.commit()

    emit('receive_private', {
        'sender': data['sender'],
        'message': message_text
    }, room=room)

@app.route('/report/product/<int:product_id>', methods=['GET', 'POST'])
@login_required
def report_product(product_id):
    product = Product.query.get_or_404(product_id)
    
    # 신고 폼 처리
    form = ReportForm()
    if form.validate_on_submit():
        # 신고 정보 추가
        report = ReportProduct(
            reporter_id=current_user.id,
            reported_user_id=product.owner.id,  # 신고 대상은 상품의 소유자
            product_id=product.id,  # 상품 ID를 명시적으로 할당
            reason=form.reason.data
        )
        db.session.add(report)
        db.session.commit()
        flash('상품이 신고되었습니다.', 'info')
        return redirect(url_for('product_detail', product_id=product.id))

    return render_template('report_product.html', form=form, product=product)


# 유저 신고
@app.route('/report/user/<int:user_id>', methods=['GET', 'POST'])
@login_required
def report_user(user_id):
    if user_id == current_user.id:
        flash('자기 자신은 신고할 수 없습니다.', 'warning')
        return redirect(url_for('index'))

    form = ReportUserForm()
    if form.validate_on_submit():
        report = ReportUser(
            reporter_id=current_user.id,
            reported_user_id=user_id,
            reason=form.reason.data
        )
        db.session.add(report)
        db.session.commit()
        flash('유저가 신고되었습니다.', 'info')
        return redirect(url_for('index'))

    return render_template('report_user.html', form=form)

@app.route('/transfer', methods=['GET', 'POST'])
@login_required
def transfer():
    # 휴면 상태인 유저는 송금을 할 수 없습니다.
    if not current_user.is_active_user:
        flash('휴면 상태로 송금을 할 수 없습니다.', 'danger')
        return redirect(url_for('index'))  # 홈 화면으로 리디렉션

    form = TransferForm()
    if form.validate_on_submit():
        receiver = User.query.filter_by(username=form.receiver_username.data).first()
        amount = form.amount.data

        if not receiver:
            flash('존재하지 않는 사용자입니다.', 'danger')
        elif receiver.id == current_user.id:
            flash('자기 자신에게는 송금할 수 없습니다.', 'warning')
        elif current_user.balance < amount:
            flash('잔액이 부족합니다.', 'danger')
        else:
            # 잔액 차감/증가
            current_user.balance -= amount
            receiver.balance += amount

            # 거래 내역 저장
            transaction = Transaction(
                sender_id=current_user.id,
                receiver_id=receiver.id,
                amount=amount
            )
            db.session.add(transaction)
            db.session.commit()

            flash(f'{receiver.username}님에게 {amount}원 송금 완료!', 'success')
            return redirect(url_for('transfer'))

    return render_template('transfer.html', form=form)


@app.route('/search', methods=['GET', 'POST'])
def search():
    keyword = request.args.get('q')
    results = []

    if keyword:
        results = Product.query.filter(
            Product.title.contains(keyword) | Product.description.contains(keyword)
        ).order_by(Product.created_at.desc()).all()

    return render_template('search.html', keyword=keyword, results=results)

def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user.is_authenticated or not current_user.is_admin:
            flash('관리자만 접근 가능합니다.', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated_function

@app.route('/admin', methods=['GET', 'POST'])
@admin_required
def admin():
    # 폼 객체 생성 (필요한 경우)
    form = ReportForm()  # 필요한 폼 클래스를 사용하세요

    # 폼 제출 처리
    if form.validate_on_submit():
        # 폼 데이터 처리 (필요한 경우)
        pass

    # 템플릿에 표시할 데이터 가져오기
    reported_products = ReportProduct.query.all()  # 신고된 상품 조회
    reported_users = ReportUser.query.all()  # 신고된 유저 조회
    users = User.query.all()  # 전체 유저 조회
    transactions = Transaction.query.all()  # 최근 거래 내역 조회

    return render_template('admin.html', form=form, 
                           reported_products=reported_products,
                           reported_users=reported_users,
                           users=users, 
                           transactions=transactions)


@app.route('/admin/deactivate_user/<int:user_id>')
@admin_required
def deactivate_user(user_id):
    user = User.query.get_or_404(user_id)
    user.is_active_user = False
    db.session.commit()
    flash(f'{user.username} 님을 휴면 처리했습니다.', 'info')
    return redirect(url_for('admin'))

# 휴면 해제 (활성 상태로 변경)
@app.route('/admin/reactivate_user/<int:user_id>')
@admin_required
def reactivate_user(user_id):
    user = User.query.get_or_404(user_id)
    if not user.is_active_user:
        user.is_active_user = True
        db.session.commit()
        flash(f'{user.username} 님의 휴면이 해제되었습니다.', 'info')
    else:
        flash(f'{user.username} 님은 이미 활성 상태입니다.', 'warning')
    return redirect(url_for('admin'))

@app.route('/delete_product/<int:product_id>', methods=['POST'])
@admin_required
def delete_product(product_id):
    # 상품 조회
    product = Product.query.get_or_404(product_id)
    
    # 신고된 상품에 대한 처리 (product_id를 올바르게 설정)
    reported_product = ReportProduct.query.filter_by(product_id=product.id).first()
    
    # 만약 신고된 상품이라면, 삭제 불가 처리
    if reported_product:
        flash("이 상품은 이미 신고되었습니다. 상품을 삭제할 수 없습니다.", 'danger')
        return redirect(url_for('admin'))  # 관리자 페이지로 리다이렉트
    
    # 상품 삭제
    db.session.delete(product)
    db.session.commit()
    flash('상품이 삭제되었습니다.', 'info')
    return redirect(url_for('admin'))


@app.route('/review/<int:product_id>', methods=['GET', 'POST'])
@login_required
def review(product_id):
    product = Product.query.get_or_404(product_id)
    form = ReviewForm()

    if form.validate_on_submit():
        review = Review(
            product_id=product.id,
            reviewer_id=current_user.id,
            rating=form.rating.data,
            comment=form.comment.data
        )
        db.session.add(review)
        db.session.commit()
        flash("리뷰가 등록되었습니다.", "success")
        return redirect(url_for('product_detail', product_id=product.id))

    return render_template('review.html', product=product, form=form)

@app.route('/buy/<int:product_id>', methods=['POST'])
@login_required
def buy_product(product_id):
    product = Product.query.get_or_404(product_id)

    if product.is_sold:
        flash('이미 판매 완료된 상품입니다.', 'warning')
        return redirect(url_for('product_detail', product_id=product.id))

    if current_user.id == product.owner.id:
        flash('자신의 상품은 구매할 수 없습니다.', 'danger')
        return redirect(url_for('product_detail', product_id=product.id))

    if current_user.balance < product.price:
        flash('잔액이 부족합니다.', 'danger')
        return redirect(url_for('product_detail', product_id=product.id))

    # 잔액 차감 및 판매 상태 변경
    current_user.balance -= product.price
    product.owner.balance += product.price
    product.is_sold = True

    # 거래 기록 저장
    transaction = Transaction(
        sender_id=current_user.id,
        receiver_id=product.owner.id,
        product_id=product.id,
        amount=product.price
    )
    db.session.add(transaction)
    db.session.commit()

    flash('상품을 성공적으로 구매했습니다.', 'success')
    return redirect(url_for('product_detail', product_id=product.id))

@app.route('/my_purchases')
@login_required
def my_purchases():
    # 사용자 ID로 거래 내역을 조회하여 구매한 상품을 가져옵니다
    purchased_products = Product.query.join(Transaction, Product.id == Transaction.product_id) \
        .filter(Transaction.receiver_id == current_user.id, Product.is_sold == True) \
        .all()

    return render_template('my_purchases.html', products=purchased_products)


@app.route('/inbox')
@login_required
def inbox():
    # 나에게 메시지를 보낸 유저 목록만 distinct하게 뽑기
    sender_ids = db.session.query(Message.sender_id).filter_by(receiver_id=current_user.id).distinct()
    senders = User.query.filter(User.id.in_(sender_ids)).all()
    return render_template('inbox.html', senders=senders)

@socketio.on('send_message')
def handle_send_message(data):
    msg = GlobalMessage(username=data['username'], content=data['content'])
    db.session.add(msg)
    db.session.commit()
    emit('receive_message', data, broadcast=True)

if __name__ == '__main__':                                                                 socketio.run(app, debug=True)


