const socket = io();
const sendBtn = document.getElementById("send-btn");
const input = document.getElementById("message-input");
const chatBox = document.getElementById("chat-box");

// username 값은 템플릿에서 주입해야 함
const username = document.getElementById("current-username").value;

sendBtn.onclick = () => {
  const message = input.value;
  if (message.trim() !== "") {
    socket.emit("send_message", {
      username: username,
      content: message
    });
    input.value = "";
  }
};

socket.on("receive_message", data => {
  const p = document.createElement("p");
  p.innerHTML = `<strong>${data.username}</strong>: ${data.content}`;
  chatBox.appendChild(p);
});

