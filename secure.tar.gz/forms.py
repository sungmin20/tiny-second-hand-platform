from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, TextAreaField, IntegerField
from wtforms.validators import DataRequired, EqualTo, Length, NumberRange, Optional

# 회원가입 폼
class RegisterForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=20)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    confirm = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Register')

# 로그인 폼
class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class BuyProductForm(FlaskForm):
    submit = SubmitField('💰 구매하기')

# 마이페이지 소개글/비밀번호 변경
class UpdateProfileForm(FlaskForm):
    introduction = TextAreaField('Introduction', validators=[Optional(), Length(max=200)])
    new_password = PasswordField('New Password', validators=[Optional(), Length(min=6)])
    submit = SubmitField('Update')

# 상품 등록 폼
class ProductForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired(), Length(max=100)])
    description = TextAreaField('Description', validators=[DataRequired()])
    price = IntegerField('Price', validators=[DataRequired(), NumberRange(min=0)])
    submit = SubmitField('Post Product')

# 신고 폼 (유저/상품 공통)
class ReportForm(FlaskForm):
    reason = TextAreaField('Reason', validators=[DataRequired(), Length(max=200)])
    submit = SubmitField('Submit Report')

# 송금 폼
class TransferForm(FlaskForm):
    receiver_username = StringField('To (Username)', validators=[DataRequired()])
    amount = IntegerField('Amount', validators=[DataRequired(), NumberRange(min=1)])
    submit = SubmitField('Transfer')

class ReviewForm(FlaskForm):
    rating = IntegerField("별점 (1~5)", validators=[DataRequired(), NumberRange(min=1, max=5)])
    comment = TextAreaField("후기", validators=[Optional()])
    submit = SubmitField("리뷰 남기기")

class ReportUserForm(FlaskForm):
    reason = StringField('신고 사유', validators=[DataRequired()])
    submit = SubmitField('신고')

